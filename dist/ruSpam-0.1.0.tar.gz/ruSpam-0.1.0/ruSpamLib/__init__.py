from .detector import is_spam
